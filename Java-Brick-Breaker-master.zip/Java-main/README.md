Java Stuff, and a Hello world program (tradition). More stuff will be added.
